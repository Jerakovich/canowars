module Juego where

import System.Random (randomRIO)
import System.IO
import Control.Monad (when)

-- Función para mostrar el campo de batalla
mostrarCampo :: Int -> Int -> Maybe (Int, Int) -> Maybe (Int, Int) -> IO ()
mostrarCampo pos1 pos2 _ _ = do
    putStrLn $ replicate pos1 ' ' ++ "0-¨°°¨-0"
    putStrLn $ replicate pos2 ' ' ++ "0-¨°°¨-0"

disparar1 :: Int -> Int -> Int -> Int -> Int -> Int -> Int -> Int -> IO ()
disparar1 pos1 pos2 hp1 hp2 fuel1 fuel2 ang1 ang2 = do
    putStrLn "Mortero 1 dispara."
    -- Aquí podrías calcular algún cambio en hp, posición o alguna lógica.
    let nuevoHp2 = hp2 - 5  -- Ejemplo de reducción de hp del oponente
    mainInputLoop pos1 pos2 Nothing Nothing hp1 nuevoHp2 fuel1 fuel2 ang1 ang2

disparar2 :: Int -> Int -> Int -> Int -> Int -> Int -> Int -> Int -> IO ()
disparar2 pos1 pos2 hp1 hp2 fuel1 fuel2 ang1 ang2 = do
    putStrLn "Mortero 2 dispara."
    -- Aquí podrías calcular algún cambio en hp, posición o alguna lógica.
    let nuevoHp2 = hp2 - 5  -- Ejemplo de reducción de hp del oponente
    mainInputLoop pos1 pos2 Nothing Nothing hp1 nuevoHp2 fuel1 fuel2 ang1 ang2

-- Cálculo de daño con probabilidad de crítico
calcularDanio :: IO Int
calcularDanio = do
    baseDamage <- randomRIO (1, 3)
    crit <- randomRIO (1, 100) :: IO Int
    return $ if crit <= 5 then baseDamage + 6 else baseDamage

-- Función principal del bucle del juego
mainInputLoop :: Int -> Int -> Maybe (Int, Int) -> Maybe (Int, Int) -> Int -> Int -> Int -> Int -> Int -> Int -> IO ()
mainInputLoop pos1 pos2 mbDisparo1 mbDisparo2 hp1 hp2 fuel1 fuel2 ang1 ang2 = do
    hSetEcho stdin False
    mostrarCampo pos1 pos2 mbDisparo1 mbDisparo2
    when (hp1 > 0 && hp2 > 0) $ do
        putStrLn "\nElige una acción (a: mover mortero 1, d: mover mortero 1, <: mover mortero 2, >: mover mortero 2, w: disparar mortero 1, e: disparar mortero 2, q: salir): "
        char <- getChar  -- Espera la entrada del usuario
        case char of
            'a' -> moverMortero pos1 pos2 mbDisparo1 mbDisparo2 hp1 hp2 fuel1 fuel2 ang1 ang2 True (-1)
            'd' -> moverMortero pos1 pos2 mbDisparo1 mbDisparo2 hp1 hp2 fuel1 fuel2 ang1 ang2 True 1
            '<' -> moverMortero pos1 pos2 mbDisparo1 mbDisparo2 hp1 hp2 fuel1 fuel2 ang1 ang2 False (-1)
            '>' -> moverMortero pos1 pos2 mbDisparo1 mbDisparo2 hp1 hp2 fuel1 fuel2 ang1 ang2 False 1
            'w' -> disparar1 pos1 pos2 hp1 hp2 fuel1 fuel2 ang1 ang2  -- Llama a disparar1
            'e' -> disparar2 pos1 pos2 hp1 hp2 fuel1 fuel2 ang1 ang2  -- Llama a disparar2
            'q' -> putStrLn "Juego terminado."
            _   -> mainInputLoop pos1 pos2 mbDisparo1 mbDisparo2 hp1 hp2 fuel1 fuel2 ang1 ang2  -- Si la tecla no es válida, vuelve a mostrar el menú

moverMortero :: Int -> Int -> Maybe (Int, Int) -> Maybe (Int, Int) -> Int -> Int -> Int -> Int -> Int -> Int -> Bool -> Int -> IO ()
moverMortero pos1 pos2 mbDisparo1 mbDisparo2 hp1 hp2 fuel1 fuel2 ang1 ang2 isPlayer1 dir
    | isPlayer1 && fuel1 > 0 = mainInputLoop (max 0 (pos1 + dir)) pos2 mbDisparo1 mbDisparo2 hp1 hp2 (fuel1 - 10) fuel2 ang1 ang2
    | not isPlayer1 && fuel2 > 0 = mainInputLoop pos1 (max 41 (pos2 + dir)) mbDisparo1 mbDisparo2 hp1 hp2 fuel1 (fuel2 - 10) ang1 ang2
    | otherwise = do
        putStrLn "Combustible insuficiente para moverse."
        mainInputLoop pos1 pos2 mbDisparo1 mbDisparo2 hp1 hp2 fuel1 fuel2 ang1 ang2
