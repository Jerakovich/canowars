module Main where

import Juego (mainInputLoop)

main :: IO ()
main = do
    -- Inicializa el estado del juego
    let pos1 = 0
        pos2 = 40
        hp1 = 100
        hp2 = 100
        fuel1 = 100
        fuel2 = 100
        ang1 = 45
        ang2 = 45
    mainInputLoop pos1 pos2 Nothing Nothing hp1 hp2 fuel1 fuel2 ang1 ang2
